function Twitter() {
    return ( <>
        <h1>Welcome to Twitter Page</h1>
    </> );
}

export default Twitter;