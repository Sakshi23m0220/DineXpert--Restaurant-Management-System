function Facebook() {
    return ( <>
        <h1>Welcome to Facebook Page</h1>
    </> );
}

export default Facebook;