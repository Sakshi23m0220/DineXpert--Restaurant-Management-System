function Instagram() {
    return ( <>
        <h1>Welcome to Instagram Page</h1>
    </> );
}

export default Instagram;