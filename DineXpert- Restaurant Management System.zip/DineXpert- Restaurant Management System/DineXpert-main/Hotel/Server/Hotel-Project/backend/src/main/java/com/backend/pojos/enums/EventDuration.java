package com.backend.pojos.enums;

public enum EventDuration {
    HALF_DAY, FULL_DAY
}
