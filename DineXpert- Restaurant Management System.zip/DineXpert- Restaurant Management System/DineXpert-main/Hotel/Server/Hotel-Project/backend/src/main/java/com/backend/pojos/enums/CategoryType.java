package com.backend.pojos.enums;

public enum CategoryType {

    BREAKFAST,SOUP,STARTER,MAIN_COURSE,RICE,DESSERT,HOT_DRINK,COLD_DRINK,ROTI
}
