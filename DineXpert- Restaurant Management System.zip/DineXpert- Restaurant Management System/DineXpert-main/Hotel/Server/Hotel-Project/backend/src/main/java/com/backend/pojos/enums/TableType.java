package com.backend.pojos.enums;

public enum TableType {
    TABLE_FOR_TWO, TABLE_FOR_FOUR, TABLE_FOR_SIX, TABLE_FOR_EIGHT,TABLE_FOR_TEN  
}
