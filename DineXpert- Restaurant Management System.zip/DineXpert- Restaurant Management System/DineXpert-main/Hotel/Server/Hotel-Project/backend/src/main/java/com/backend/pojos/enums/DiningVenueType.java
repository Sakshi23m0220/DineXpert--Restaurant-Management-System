package com.backend.pojos.enums;

public enum DiningVenueType {
    PUBLIC_DINE, PRIVATE_DINE
}
