package com.backend.services.interfaces;

import com.backend.dtos.TableDTO;

public interface ITableService {
    TableDTO addTable(TableDTO tableDTO);
}
