package com.backend.pojos.enums;

public enum EventVenueType {
    CHINNA_MANDAP, ANNA_MANDAP
}
