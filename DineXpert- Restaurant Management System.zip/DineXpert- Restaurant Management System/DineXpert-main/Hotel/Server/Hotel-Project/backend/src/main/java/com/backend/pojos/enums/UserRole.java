package com.backend.pojos.enums;

public enum UserRole {

     CUSTOMER, MANAGER,ADMIN

}
