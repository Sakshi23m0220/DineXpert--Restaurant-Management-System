package com.backend.pojos.enums;

public enum PaymentType {
    UPI, CASH
}
